Greyware Automation Products
308 Oriole Ct
Murphy, TX 75094

       Voice:  (972) 867-2794
         Fax:  (972) 208-1479
Tech Support:  techsupport@greyware.com
       Sales:  sales@greyware.com
General Info:  info@greywarec.com

This program is NOT freeware.  It is shareware
distributed on a try-before-you-buy basis.  This
is the honor system; please honor it.

Licensing Options and Prices:
    http://www.greyware.com/licenses

Online Store:
    https://www.greyware.com/store


